package com.satishlabs.application_one;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
