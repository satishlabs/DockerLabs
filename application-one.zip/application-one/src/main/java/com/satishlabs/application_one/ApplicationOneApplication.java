package com.satishlabs.application_one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationOneApplication.class, args);
	}

}
